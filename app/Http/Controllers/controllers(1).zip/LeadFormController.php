<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\LeadForm;
use App\Mail\ContactMail;
use Mail;
use Session;
use Auth;
use App\Http\Controllers\HomeController;

class LeadFormController extends Controller
{
    function addregistration(Request $req)
    {
        $leadform = new LeadForm;

        $leadform->Name = $req->name;
        $leadform->Phone = $req->phone;
        $leadform->Email = $req->email;
        $leadform->CoursesIntrested = $req->coursesintrested;
        $leadform->Comments = $req->comments;

        $details = [
            'name' => $req->name,
            'phone' => $req->phone,
            'email' => $req->email,
            'coursesintrested' => $req->coursesintrested,
            'comments' => $req->comments
        ];

        $leadform->save();

        $datamail = $req->all();
        $datamail = [
            "name" => $req->name,
            "coursesintrested" => $req->coursesintrested,
        ];


        $to_name = $req->name;
        $to_email = $req->email;
        $to_email_one = 'info@youexceltraining.com';
        $to_email_two = 'youexceltraining@gmail.com';
        $to_email_three = 'youexcel.connect@gmail.com';
        $to_email_four = 'muneera.amer@youexceltraining.com';

        Mail::send("emails.Leadformmail", ["email_data" => $datamail], function ($message) use ($to_name, $to_email, $req) {
            $message->to($to_email, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });

//        Mail::send("emails.Leadformmail", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_one, $req) {
//            $message->to($to_email_one, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
//        Mail::send("emails.Leadformmail", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_two, $req) {
//            $message->to($to_email_two, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
        Mail::send("emails.Leadformmail", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_three, $req) {
            $message->to($to_email_three, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });
//        Mail::send("emails.Leadformmail", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_four, $req) {
//            $message->to($to_email_four, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });

        Session::flash('appoinmentbooked', 'Appoinment has been Successfully !!');

        // Mail::to($req)->send(new ContactMail($details));
        // Mail::to('youexceltraining@gmail.com')->send(new ContactMail($details));
        // $leadform->save();
        // Session::flash('appoinmentbooked','Appoinment has been Successfully !!');
        return redirect('/');
    }

    function nomanformcustom(Request $req)
    {
        $leadform = new LeadForm;

        $leadform->Name = $req->name;
        $leadform->Phone = $req->phone;
        $leadform->Email = $req->email;
        $leadform->CoursesIntrested = $req->coursesintrested;
        $leadform->Comments = $req->comments;

        $details = [
            'name' => $req->name,
            'phone' => $req->phone,
            'email' => $req->email,
            'coursesintrested' => $req->coursesintrested,
            'comments' => $req->comments
        ];

        $leadform->save();

        $datamail = $req->all();
        $datamail = [
            "name" => $req->name,
            "coursesintrested" => $req->coursesintrested,
        ];


        $to_name = $req->name;
        $to_email = $req->email;
        $to_email_one = 'info@youexceltraining.com';
        $to_email_two = 'youexceltraining@gmail.com';
        $to_email_three = 'youexcel.connect@gmail.com';
        $to_email_four = 'muneera.amer@youexceltraining.com';

        Mail::send("emails.Leadformmailcustom", ["email_data" => $datamail], function ($message) use ($to_name, $to_email, $req) {
            $message->to($to_email, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });

//        Mail::send("emails.Leadformmailcustom", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_one, $req) {
//            $message->to($to_email_one, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
//        Mail::send("emails.Leadformmailcustom", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_two, $req) {
//            $message->to($to_email_two, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
        Mail::send("emails.Leadformmailcustom", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_three, $req) {
            $message->to($to_email_three, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });
//        Mail::send("emails.Leadformmailcustom", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_four, $req) {
//            $message->to($to_email_four, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });

        Session::flash('appoinmentbooked', 'Appoinment has been Successfully !!');

        // Mail::to($req)->send(new ContactMail($details));
        // Mail::to('youexceltraining@gmail.com')->send(new ContactMail($details));
        // $leadform->save();
        // Session::flash('appoinmentbooked','Appoinment has been Successfully !!');
        return redirect('/');
    }
    function nomanformcustomBBS(Request $req)
    {
        $leadform = new LeadForm;

        $leadform->Name = $req->name;
        $leadform->Phone = $req->phone;
        $leadform->Email = $req->email;
        $leadform->CoursesIntrested = $req->coursesintrested;
        $leadform->Comments = $req->comments;

        $details = [
            'name' => $req->name,
            'phone' => $req->phone,
            'email' => $req->email,
            'coursesintrested' => $req->coursesintrested,
            'comments' => $req->comments
        ];

        $leadform->save();

        $datamail = $req->all();
        $datamail = [
            "name" => $req->name,
            "coursesintrested" => $req->coursesintrested,
        ];


        $to_name = $req->name;
        $to_email = $req->email;
        $to_email_one = 'info@youexceltraining.com';
        $to_email_two = 'youexceltraining@gmail.com';
        $to_email_three = 'youexcel.connect@gmail.com';
        $to_email_four = 'muneera.amer@youexceltraining.com';

        Mail::send("emails.LeadformmailcustomBBS", ["email_data" => $datamail], function ($message) use ($to_name, $to_email, $req) {
            $message->to($to_email, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });

//        Mail::send("emails.LeadformmailcustomBBS", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_one, $req) {
//            $message->to($to_email_one, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
//        Mail::send("emails.LeadformmailcustomBBS", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_two, $req) {
//            $message->to($to_email_two, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });
        Mail::send("emails.LeadformmailcustomBBS", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_three, $req) {
            $message->to($to_email_three, $to_name)->subject("Thanks for contacting YouExcel");
            $message->from("info@youexceltraining.com", "YouExcel Training");
        });
//        Mail::send("emails.LeadformmailcustomBBS", ["email_data" => $datamail], function ($message) use ($to_name, $to_email_four, $req) {
//            $message->to($to_email_four, $to_name)->subject("Thanks for contacting YouExcel");
//            $message->from("info@youexceltraining.com", "YouExcel Training");
//        });

        Session::flash('appoinmentbooked', 'Appoinment has been Successfully !!');

        // Mail::to($req)->send(new ContactMail($details));
        // Mail::to('youexceltraining@gmail.com')->send(new ContactMail($details));
        // $leadform->save();
        // Session::flash('appoinmentbooked','Appoinment has been Successfully !!');
        return redirect('/');
    }

    function showtable()
    {
        $data = LeadForm::all();
        // return view('add-course', ['Courses'=>$data]);
        return view('adminpanel.view-Leadform', compact('data'));
    }

    function delete($id)
    {
        $data = LeadForm::find($id);
        $data->delete();
        return redirect('view-Leadform');
    }

}
